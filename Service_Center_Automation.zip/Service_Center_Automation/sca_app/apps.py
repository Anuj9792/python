from django.apps import AppConfig


class ScaAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sca_app'
